# Question 1: Merge two Sorted Linked List
class ListNode:
    def __init__(self, x):
        self.val = x
        self.next = None


def mergeTwoLists(l1: ListNode, l2: ListNode) -> ListNode:
    '''
    Please DO NOT modify the given function except the TODO part.
    This function is used to merge two ordered linked lists.
    :parameter: l1, l2 are heads of two sorted linked lists.(l1 and l2 are sorted in non-decreasing order.)
    :return: head node of merged linked list
    '''
    # TODO part
    # ------- Your code start here -------
    if l1.val <= l2.val:
        headnode = l1
    else:
        l3 = l2
        l2 = l2.next
        l3.next = l1
        l1 = l3
        headnode = l1

    while l1 != None and l2 != None:
        if l1 == None or l2 == None:
            break
        if l1.next != None:
            if l1.val <= l2.val <= l1.next.val:

                l3=l2               #给l2存档到l3
                l2=l2.next          #l2指针下移,一定要立刻下移，不然会随着l3改变
                l3.next=l1.next     #l3后连上l4(即l1的下一位)——>l3节点设置完毕
                l1.next=l3          #l1后连上l3
                l1=l1.next
            elif l2.val < l1.val:
                l3 = l2
                l3.next = l1
                l1 = l3
                l2 = l2.next
            else:
                l1 = l1.next
                continue
        else:
            if l1.val <= l2.val:
                l3=l2
                l1.next = l3
                break
    # ------- End of your code -----------

    # ------- return head node -----------
    return headnode


# ------- Helper Functions  -----------
# You can use these helper functions to better complete your homework
def printList(head:ListNode):
    '''
    This function is used to print the node values of the linked list.
    '''
    curr = head
    while curr:
        print(curr.val)
        curr = curr.next


def createList(array: list) -> ListNode:
    '''
    This function is used to create a new linked list from a list.
    '''
    if not array:
        return []
    head = ListNode(array[0])
    current = head
    for value in array[1:]:
        new_node = ListNode(value)
        current.next = new_node
        current = new_node
    return head


if __name__ == '__main__':
    # examples
    list1 = [1,2,4]
    list2 = [1,3,4]
    linked1 = createList(list1)
    linked2 = createList(list2)


    head = mergeTwoLists(linked1, linked2)
    printList(head)